package main;

import javax.swing.SwingUtilities;

public class Main {
	public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new StartScreen((username, hasSavedMap) -> {
                Frame window = new Frame("City Fixer", 622, 685, false, username, hasSavedMap);
                window.requestFocusInWindow();
                window.pack();
                window.setLocationRelativeTo(null);
                window.setVisible(true);
            });
        });
	}
}
