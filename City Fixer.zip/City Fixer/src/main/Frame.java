package main;

import java.awt.Dimension;
import java.awt.Toolkit;

import javax.swing.JFrame;

import inputs.Mouse;
import inputs.WindowListener;

public class Frame extends JFrame {
	Frame(String title, int x, int y, boolean resizeable, String username, boolean hasSavedMap) {
		super(title);
		setPreferredSize(new Dimension(x,y));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setResizable(resizeable);
		
		Map map;
		
		if (hasSavedMap) {
			String savedMapPath = "/saves/" + username + "_savedMap.txt";
        	System.out.println("Username " + username + " will be loaded \nFile Path: " + savedMapPath);

            map = new Map(savedMapPath); // Create a Map with the saved map path
		} else {
			map = new Map(null);
		}
		
		add(map);
		
		//map.showWelcomeMessage(username);

		Mouse mouse = new Mouse(map.tileM, map.miniM);
		addMouseListener(mouse);

		WindowListener windowListener = new WindowListener(map.tileM, username);
		addWindowListener(windowListener);
	}
	
}
